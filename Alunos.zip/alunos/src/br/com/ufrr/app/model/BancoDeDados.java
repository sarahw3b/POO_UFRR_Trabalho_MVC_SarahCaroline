/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ufrr.app.model;

import java.util.ArrayList;
import java.util.List;


public class BancoDeDados {

    private static BancoDeDados instance;
    private List<Aluno> alunos;


    private BancoDeDados() {
        alunos = new ArrayList<>();
    }
    public static BancoDeDados getInstance() {
        if (instance == null) {
            instance = new BancoDeDados();
        }
        return instance;
    }
    public List<Aluno> getAlunos() {
        return alunos;
    }
}