package br.com.ufrr.app.view;

import br.com.ufrr.app.controller.AlunoController;
import br.com.ufrr.app.model.Aluno;
import java.util.List;
import javax.swing.*;

public class TelaAluno extends JFrame {

    private JTextField txtNome;
    private JTextField txtCpf;
    private JButton btnSalvar;
    private JButton btnListar;

    private AlunoController controller;

    public TelaAluno() {
        controller = new AlunoController();

        setTitle("Cadastro de Aluno");
        setSize(350, 220);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(10, 10, 80, 25);
        add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(90, 10, 220, 25);
        add(txtNome);

        JLabel lblCpf = new JLabel("CPF:");
        lblCpf.setBounds(10, 45, 80, 25);
        add(lblCpf);

        txtCpf = new JTextField();
        txtCpf.setBounds(90, 45, 220, 25);
        add(txtCpf);

        btnSalvar = new JButton("Salvar");
        btnSalvar.setBounds(30, 90, 120, 30);
        add(btnSalvar);

        btnListar = new JButton("Listar no Console");
        btnListar.setBounds(170, 90, 160, 30);
        add(btnListar);

        btnSalvar.addActionListener(e -> {
            try {
                controller.cadastrarAluno(
                        txtNome.getText(),
                        txtCpf.getText()
                );
                JOptionPane.showMessageDialog(this, "Aluno cadastrado com sucesso!");
                txtNome.setText("");
                txtCpf.setText("");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(
                        this,
                        ex.getMessage(),
                        "Erro",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        });

        btnListar.addActionListener(e -> {
            List<Aluno> alunos = controller.listarAlunos();

            System.out.println("=== LISTA DE ALUNOS ===");
            for (Aluno a : alunos) {
                System.out.println(
                     "ID: " + a.getId() +
                     " | Nome: " + a.getNome() +
                     " | CPF: " + a.getCpf() +
                     " | Matrícula: " + a.getMatricula()
        );
    }
});

    }
}
