/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ufrr.app.controller;

import br.com.ufrr.app.model.Aluno;
import br.com.ufrr.app.model.AlunoDAO;
import java.util.List;


public class AlunoController {
    private AlunoDAO dao;
    
    public AlunoController() {
        dao = new AlunoDAO();
    }
    public void cadastrarAluno(String nome, String cpf) {

        if (!cpfValido(cpf)) {
            throw new IllegalArgumentException("CPF inválido. Use 11 dígitos numéricos.");
        }

        if (cpfJaExiste(cpf)) {
            throw new IllegalArgumentException("CPF já cadastrado no sistema.");
        }

        int novoId = dao.listarTodos().size() + 1;
        String matricula = "MAT" + novoId;

        Aluno aluno = new Aluno(novoId, nome, cpf, matricula);
        dao.salvar(aluno);
    }



    private boolean cpfValido(String cpf) {
        if (cpf == null) {
        return false;
    }
        if (!cpf.matches("\\d{11}")) {
        return false;
    }
    return true;
}
    private boolean cpfJaExiste(String cpf) {
        return dao.listarTodos()
              .stream()
              .anyMatch(a -> a.getCpf().equals(cpf));
}

    public List<Aluno> listarAlunos() {
        return dao.listarTodos();
    }
}