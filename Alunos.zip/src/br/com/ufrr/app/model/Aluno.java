package br.com.ufrr.app.model;

public class Aluno {

    private int id;
    private String nome;
    private String cpf;
    private String matricula;

    public Aluno(int id, String nome, String cpf, String matricula) {
        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
        this.matricula = matricula;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getMatricula() {
        return matricula;
    }
}
