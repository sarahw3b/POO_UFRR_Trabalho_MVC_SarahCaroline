/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ufrr.app.model;

import java.util.List;


public class AlunoDAO {
    public void salvar(Aluno aluno) {
        BancoDeDados banco = BancoDeDados.getInstance();
        banco.getAlunos().add(aluno);
}
    public List<Aluno> listarTodos() {
        BancoDeDados banco = BancoDeDados.getInstance();
        return banco.getAlunos();
}
}